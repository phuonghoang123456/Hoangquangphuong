﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BTT8_lab6_hoangquangphuong
{
    public partial class Form1 : Form
    {
        // 🔹 Khai báo chuỗi kết nối
        SqlConnection sqlCon = null;
        string strCon = @"Server=LAPTOP-8GMP6I6L\MSSQLSERVER01;Database=QuanLyBanSach;User Id=sa;Password=123;TrustServerCertificate=True";

        public Form1()
        {
            InitializeComponent();
        }

        // 🔹 Hàm mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // 🔹 Hàm đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ============================================================
        // 🧩 THỰC HÀNH 1: HIỂN THỊ DANH SÁCH NXB
        // ============================================================
        private void HienThiDanhSachNXB()
        {
            try
            {
                MoKetNoi();
                SqlCommand cmd = new SqlCommand("SELECT MaNXB, TenNXB, DiaChi FROM NhaXuatBan", sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();

                lsvDanhSach.Items.Clear();
                while (reader.Read())
                {
                    string ma = reader["MaNXB"].ToString();
                    string ten = reader["TenNXB"].ToString();
                    string diachi = reader["DiaChi"].ToString();

                    ListViewItem item = new ListViewItem(ma);
                    item.SubItems.Add(ten);
                    item.SubItems.Add(diachi);
                    lsvDanhSach.Items.Add(item);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Lỗi tải danh sách: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // 🔹 Khi form load
        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDanhSachNXB();
        }

        // 🔹 Khi chọn dòng trong ListView
        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0) return;
            ListViewItem item = lsvDanhSach.SelectedItems[0];

            txtMaNXB.Text = item.SubItems[0].Text;
            txtTenNXB.Text = item.SubItems[1].Text;
            txtDiaChi.Text = item.SubItems[2].Text;
        }

        // 🔹 Nút làm mới danh sách
        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            txtMaNXB.Clear();
            txtTenNXB.Clear();
            txtDiaChi.Clear();
            HienThiDanhSachNXB();
        }

        // ============================================================
        // 🧩 THỰC HÀNH 2: THÊM NHÀ XUẤT BẢN
        // ============================================================
        private void btnThem_Click(object sender, EventArgs e)
        {
            string ma = txtThemMa.Text.Trim();
            string ten = txtThemTen.Text.Trim();
            string diachi = txtThemDiaChi.Text.Trim();

            // Kiểm tra dữ liệu nhập
            if (string.IsNullOrEmpty(ma) || string.IsNullOrEmpty(ten))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Mã NXB và Tên NXB!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                MoKetNoi();

                string sql = "INSERT INTO NhaXuatBan (MaNXB, TenNXB, DiaChi) VALUES (@ma, @ten, @diachi)";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@ma", ma);
                cmd.Parameters.AddWithValue("@ten", ten);
                cmd.Parameters.AddWithValue("@diachi", diachi);

                int kq = cmd.ExecuteNonQuery();

                if (kq > 0)
                {
                    MessageBox.Show(" Thêm nhà xuất bản thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtThemMa.Clear();
                    txtThemTen.Clear();
                    txtThemDiaChi.Clear();
                    HienThiDanhSachNXB();
                    tabMain.SelectedTab = tabDanhSach; // Quay lại tab danh sách
                }
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) // Trùng khóa chính
                    MessageBox.Show(" Mã NXB đã tồn tại. Vui lòng nhập mã khác!", "Lỗi trùng khóa", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show(" Lỗi SQL: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Lỗi thêm dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}
