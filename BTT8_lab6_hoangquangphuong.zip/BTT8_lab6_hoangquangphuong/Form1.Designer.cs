﻿namespace BTT8_lab6_hoangquangphuong
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabDanhSach = new System.Windows.Forms.TabPage();
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpNhapLieu = new System.Windows.Forms.GroupBox();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtTenNXB = new System.Windows.Forms.TextBox();
            this.txtMaNXB = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.lblTenNXB = new System.Windows.Forms.Label();
            this.lblMaNXB = new System.Windows.Forms.Label();
            this.lsvDanhSach = new System.Windows.Forms.ListView();
            this.colMa = new System.Windows.Forms.ColumnHeader();
            this.colTen = new System.Windows.Forms.ColumnHeader();
            this.colDiaChi = new System.Windows.Forms.ColumnHeader();
            this.tabThem = new System.Windows.Forms.TabPage();
            this.grpThemNXB = new System.Windows.Forms.GroupBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.txtThemDiaChi = new System.Windows.Forms.TextBox();
            this.txtThemTen = new System.Windows.Forms.TextBox();
            this.txtThemMa = new System.Windows.Forms.TextBox();
            this.lblThemDiaChi = new System.Windows.Forms.Label();
            this.lblThemTen = new System.Windows.Forms.Label();
            this.lblThemMa = new System.Windows.Forms.Label();
            this.tabSua = new System.Windows.Forms.TabPage();
            this.tabXoa = new System.Windows.Forms.TabPage();
            this.tabMain.SuspendLayout();
            this.tabDanhSach.SuspendLayout();
            this.grpMain.SuspendLayout();
            this.grpNhapLieu.SuspendLayout();
            this.tabThem.SuspendLayout();
            this.grpThemNXB.SuspendLayout();
            this.SuspendLayout();

            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabDanhSach);
            this.tabMain.Controls.Add(this.tabThem);
            this.tabMain.Controls.Add(this.tabSua);
            this.tabMain.Controls.Add(this.tabXoa);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(900, 480);
            this.tabMain.TabIndex = 0;
            // 
            // tabDanhSach
            // 
            this.tabDanhSach.Controls.Add(this.grpMain);
            this.tabDanhSach.Location = new System.Drawing.Point(4, 24);
            this.tabDanhSach.Name = "tabDanhSach";
            this.tabDanhSach.Padding = new System.Windows.Forms.Padding(3);
            this.tabDanhSach.Size = new System.Drawing.Size(892, 452);
            this.tabDanhSach.TabIndex = 0;
            this.tabDanhSach.Text = "Danh sách NXB";
            this.tabDanhSach.UseVisualStyleBackColor = true;
            // 
            // grpMain
            // 
            this.grpMain.Controls.Add(this.lblTitle);
            this.grpMain.Controls.Add(this.grpNhapLieu);
            this.grpMain.Controls.Add(this.lsvDanhSach);
            this.grpMain.Location = new System.Drawing.Point(8, 6);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(876, 440);
            this.grpMain.TabIndex = 0;
            this.grpMain.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(334, 16);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(187, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Danh sách dữ liệu";
            // 
            // grpNhapLieu
            // 
            this.grpNhapLieu.Controls.Add(this.btnLamMoi);
            this.grpNhapLieu.Controls.Add(this.txtDiaChi);
            this.grpNhapLieu.Controls.Add(this.txtTenNXB);
            this.grpNhapLieu.Controls.Add(this.txtMaNXB);
            this.grpNhapLieu.Controls.Add(this.lblDiaChi);
            this.grpNhapLieu.Controls.Add(this.lblTenNXB);
            this.grpNhapLieu.Controls.Add(this.lblMaNXB);
            this.grpNhapLieu.Location = new System.Drawing.Point(515, 53);
            this.grpNhapLieu.Name = "grpNhapLieu";
            this.grpNhapLieu.Size = new System.Drawing.Size(351, 373);
            this.grpNhapLieu.TabIndex = 2;
            this.grpNhapLieu.TabStop = false;
            this.grpNhapLieu.Text = "Thông tin nhập liệu";
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.Location = new System.Drawing.Point(112, 192);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(130, 28);
            this.btnLamMoi.TabIndex = 6;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = true;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(112, 140);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.ReadOnly = true;
            this.txtDiaChi.Size = new System.Drawing.Size(214, 23);
            this.txtDiaChi.TabIndex = 5;
            // 
            // txtTenNXB
            // 
            this.txtTenNXB.Location = new System.Drawing.Point(112, 98);
            this.txtTenNXB.Name = "txtTenNXB";
            this.txtTenNXB.ReadOnly = true;
            this.txtTenNXB.Size = new System.Drawing.Size(214, 23);
            this.txtTenNXB.TabIndex = 4;
            // 
            // txtMaNXB
            // 
            this.txtMaNXB.Location = new System.Drawing.Point(112, 56);
            this.txtMaNXB.Name = "txtMaNXB";
            this.txtMaNXB.ReadOnly = true;
            this.txtMaNXB.Size = new System.Drawing.Size(214, 23);
            this.txtMaNXB.TabIndex = 3;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(24, 143);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(48, 15);
            this.lblDiaChi.TabIndex = 2;
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // lblTenNXB
            // 
            this.lblTenNXB.AutoSize = true;
            this.lblTenNXB.Location = new System.Drawing.Point(24, 101);
            this.lblTenNXB.Name = "lblTenNXB";
            this.lblTenNXB.Size = new System.Drawing.Size(57, 15);
            this.lblTenNXB.TabIndex = 1;
            this.lblTenNXB.Text = "Tên NXB:";
            // 
            // lblMaNXB
            // 
            this.lblMaNXB.AutoSize = true;
            this.lblMaNXB.Location = new System.Drawing.Point(24, 59);
            this.lblMaNXB.Name = "lblMaNXB";
            this.lblMaNXB.Size = new System.Drawing.Size(55, 15);
            this.lblMaNXB.TabIndex = 0;
            this.lblMaNXB.Text = "Mã NXB:";
            // 
            // lsvDanhSach
            // 
            this.lsvDanhSach.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colMa,
            this.colTen,
            this.colDiaChi});
            this.lsvDanhSach.FullRowSelect = true;
            this.lsvDanhSach.GridLines = true;
            this.lsvDanhSach.HideSelection = false;
            this.lsvDanhSach.Location = new System.Drawing.Point(12, 53);
            this.lsvDanhSach.MultiSelect = false;
            this.lsvDanhSach.Name = "lsvDanhSach";
            this.lsvDanhSach.Size = new System.Drawing.Size(497, 373);
            this.lsvDanhSach.TabIndex = 1;
            this.lsvDanhSach.UseCompatibleStateImageBehavior = false;
            this.lsvDanhSach.View = System.Windows.Forms.View.Details;
            this.lsvDanhSach.SelectedIndexChanged += new System.EventHandler(this.lsvDanhSach_SelectedIndexChanged);
            // 
            // colMa
            // 
            this.colMa.Text = "Mã NXB";
            this.colMa.Width = 100;
            // 
            // colTen
            // 
            this.colTen.Text = "Tên NXB";
            this.colTen.Width = 200;
            // 
            // colDiaChi
            // 
            this.colDiaChi.Text = "Địa chỉ";
            this.colDiaChi.Width = 180;
            // 
            // tabThem
            // 
            this.tabThem.Controls.Add(this.grpThemNXB);
            this.tabThem.Location = new System.Drawing.Point(4, 24);
            this.tabThem.Name = "tabThem";
            this.tabThem.Padding = new System.Windows.Forms.Padding(3);
            this.tabThem.Size = new System.Drawing.Size(892, 452);
            this.tabThem.TabIndex = 1;
            this.tabThem.Text = "Thêm NXB";
            this.tabThem.UseVisualStyleBackColor = true;

            // 
            // grpThemNXB
            // 
            this.grpThemNXB.Controls.Add(this.btnThem);
            this.grpThemNXB.Controls.Add(this.txtThemDiaChi);
            this.grpThemNXB.Controls.Add(this.txtThemTen);
            this.grpThemNXB.Controls.Add(this.txtThemMa);
            this.grpThemNXB.Controls.Add(this.lblThemDiaChi);
            this.grpThemNXB.Controls.Add(this.lblThemTen);
            this.grpThemNXB.Controls.Add(this.lblThemMa);
            this.grpThemNXB.Location = new System.Drawing.Point(250, 60);
            this.grpThemNXB.Name = "grpThemNXB";
            this.grpThemNXB.Size = new System.Drawing.Size(400, 300);
            this.grpThemNXB.TabIndex = 0;
            this.grpThemNXB.TabStop = false;
            this.grpThemNXB.Text = "Thêm Nhà Xuất Bản";

            // 
            // lblThemMa
            // 
            this.lblThemMa.AutoSize = true;
            this.lblThemMa.Location = new System.Drawing.Point(50, 70);
            this.lblThemMa.Text = "Mã NXB:";

            // 
            // txtThemMa
            // 
            this.txtThemMa.Location = new System.Drawing.Point(150, 67);
            this.txtThemMa.Size = new System.Drawing.Size(200, 23);

            // 
            // lblThemTen
            // 
            this.lblThemTen.AutoSize = true;
            this.lblThemTen.Location = new System.Drawing.Point(50, 120);
            this.lblThemTen.Text = "Tên NXB:";

            // 
            // txtThemTen
            // 
            this.txtThemTen.Location = new System.Drawing.Point(150, 117);
            this.txtThemTen.Size = new System.Drawing.Size(200, 23);

            // 
            // lblThemDiaChi
            // 
            this.lblThemDiaChi.AutoSize = true;
            this.lblThemDiaChi.Location = new System.Drawing.Point(50, 170);
            this.lblThemDiaChi.Text = "Địa chỉ:";

            // 
            // txtThemDiaChi
            // 
            this.txtThemDiaChi.Location = new System.Drawing.Point(150, 167);
            this.txtThemDiaChi.Size = new System.Drawing.Size(200, 23);

            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(140, 230);
            this.btnThem.Size = new System.Drawing.Size(130, 35);
            this.btnThem.Text = "Thêm nhà xuất bản";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);

            // 
            // tabSua & tabXoa
            // 
            this.tabSua.Text = "Sửa NXB";
            this.tabXoa.Text = "Xóa NXB";

            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(900, 480);
            this.Controls.Add(this.tabMain);
            this.Name = "Form1";
            this.Text = "1150080112 - Hoàng Quang Phương";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabDanhSach;
        private System.Windows.Forms.TabPage tabThem;
        private System.Windows.Forms.TabPage tabSua;
        private System.Windows.Forms.TabPage tabXoa;
        private System.Windows.Forms.GroupBox grpMain;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpNhapLieu;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtTenNXB;
        private System.Windows.Forms.TextBox txtMaNXB;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.Label lblTenNXB;
        private System.Windows.Forms.Label lblMaNXB;
        private System.Windows.Forms.ListView lsvDanhSach;
        private System.Windows.Forms.ColumnHeader colMa;
        private System.Windows.Forms.ColumnHeader colTen;
        private System.Windows.Forms.ColumnHeader colDiaChi;

        private System.Windows.Forms.GroupBox grpThemNXB;
        private System.Windows.Forms.Label lblThemMa;
        private System.Windows.Forms.Label lblThemTen;
        private System.Windows.Forms.Label lblThemDiaChi;
        private System.Windows.Forms.TextBox txtThemMa;
        private System.Windows.Forms.TextBox txtThemTen;
        private System.Windows.Forms.TextBox txtThemDiaChi;
        private System.Windows.Forms.Button btnThem;
    }
}
