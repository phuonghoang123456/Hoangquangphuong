﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace HoangQuangPhuong_BTB5
{
    class Program
    {
        static void Main()
        {
            // Mảng đã sắp xếp tăng dần (ví dụ)
            int[] arr = { 1, 3, 5, 7, 9 };
            int n = arr.Length;

            Console.WriteLine("Mảng ban đầu:");
            foreach (int a in arr)
                Console.Write(a + " ");
            Console.WriteLine();

            // Nhập số cần chèn
            Console.Write("Nhập số nguyên cần chèn: ");
            int x = Convert.ToInt32(Console.ReadLine());

            // Tìm vị trí chèn
            int pos = n; // mặc định chèn cuối
            for (int i = 0; i < n; i++)
            {
                if (x <= arr[i])
                {
                    pos = i;
                    break;
                }
            }

            // Tạo mảng mới có thêm 1 phần tử
            int[] newArr = new int[n + 1];

            // Sao chép và chèn
            for (int i = 0; i < pos; i++)
                newArr[i] = arr[i];

            newArr[pos] = x;

            for (int i = pos; i < n; i++)
                newArr[i + 1] = arr[i];

            // In mảng mới
            Console.WriteLine("Mảng sau khi chèn:");
            foreach (int a in newArr)
                Console.Write(a + " ");
            Console.WriteLine();

            Console.ReadLine(); // giữ console mở
        }
    }
}