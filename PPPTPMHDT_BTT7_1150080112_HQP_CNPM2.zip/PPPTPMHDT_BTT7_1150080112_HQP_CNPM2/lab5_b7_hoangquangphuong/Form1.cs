﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab5_b7_hoangquangphuong
{
    public partial class Form1 : Form
    {
        // Chuỗi kết nối tới file cơ sở dữ liệu .mdf
        string strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\giaithuat\BAITAP_BUOI5\lab5_b7_hoangquangphuong\1150080112_hoangquangphuong_lab5.mdf;Integrated Security=True";

        // Đối tượng kết nối
        SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        // ---------------- Mở kết nối ----------------
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // ---------------- Đóng kết nối ----------------
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ---------------- Hiển thị danh sách sinh viên ----------------
        private void HienThiDanhSach()
        {
            try
            {
                MoKetNoi();

                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "SELECT * FROM SinhVien";
                sqlCmd.Connection = sqlCon;

                lsvDanhSachSV.Items.Clear();
                SqlDataReader reader = sqlCmd.ExecuteReader();

                while (reader.Read())
                {
                    string maSv = reader.GetString(0);
                    string tenSV = reader.GetString(1);
                    string gioiTinh = reader.GetString(2);
                    string ngaySinh = reader.GetDateTime(3).ToString("dd/MM/yyyy");
                    string queQuan = reader.GetString(4);
                    string maLop = reader.GetString(5);

                    ListViewItem lvi = new ListViewItem(maSv);
                    lvi.SubItems.Add(tenSV);
                    lvi.SubItems.Add(gioiTinh);
                    lvi.SubItems.Add(ngaySinh);
                    lvi.SubItems.Add(queQuan);
                    lvi.SubItems.Add(maLop);
                    lsvDanhSachSV.Items.Add(lvi);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // ---------------- Sự kiện nút Thêm sinh viên ----------------
        private void btnThemSinhVien_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();

                string maSV = txtMaSV.Text.Trim();
                string tenSV = txtTenSV.Text.Trim();
                string gioiTinh = cbGioiTinh.Text;
                string ngaySinh = dtpNgaySinh.Value.Month + "/" +
                                  dtpNgaySinh.Value.Day + "/" +
                                  dtpNgaySinh.Value.Year;
                string queQuan = txtQueQuan.Text.Trim();
                string maLop = txtMaLop.Text.Trim();

                // Không dùng Parameter => ghép chuỗi trực tiếp
                string sql = "INSERT INTO SinhVien VALUES ('" + maSV + "', N'" + tenSV + "', N'" +
                             gioiTinh + "', '" + ngaySinh + "', N'" + queQuan + "', '" + maLop + "')";

                SqlCommand sqlCmd = new SqlCommand(sql, sqlCon);
                int kq = sqlCmd.ExecuteNonQuery();

                if (kq > 0)
                {
                    MessageBox.Show("Thêm sinh viên thành công!", "Thông báo");
                    HienThiDanhSach();
                }
                else
                {
                    MessageBox.Show("Không thể thêm sinh viên!", "Lỗi");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Thêm dữ liệu bị lỗi!\n" + ex.Message, "Thông báo");
            }
            finally
            {
                DongKetNoi();
            }
        }

        // ---------------- Form Load ----------------
        private void Form1_Load(object sender, EventArgs e)
        {
            cbGioiTinh.Items.Add("Nam");
            cbGioiTinh.Items.Add("Nữ");
            cbGioiTinh.SelectedIndex = 0; // Mặc định chọn Nam

            HienThiDanhSach();
        }
    }
}
