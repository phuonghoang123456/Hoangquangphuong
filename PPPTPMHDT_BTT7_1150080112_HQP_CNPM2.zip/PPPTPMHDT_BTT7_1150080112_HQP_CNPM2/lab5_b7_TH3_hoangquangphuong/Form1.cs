﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab5_b7_TH3_hoangquangphuong
{
    public partial class Form1 : Form
    {
        // 🔗 Chuỗi kết nối tới file CSDL .mdf
        private readonly string strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;
                                           AttachDbFilename=|DataDirectory|\1150080112_hoangquangphuong_lab5.mdf;
                                           Integrated Security=True";

        private SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        // 📂 Mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // 📁 Đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // 📋 Hiển thị danh sách sinh viên
        private void HienThiDanhSach()
        {
            try
            {
                MoKetNoi();
                SqlCommand cmd = new SqlCommand("SELECT * FROM SinhVien", sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();
                lsvDanhSachSV.Items.Clear();

                while (reader.Read())
                {
                    string maSV = reader.GetString(0);
                    string tenSV = reader.GetString(1);
                    string gioiTinh = reader.GetString(2);
                    string ngaySinh = reader.GetDateTime(3).ToString("dd/MM/yyyy");
                    string queQuan = reader.GetString(4);
                    string maLop = reader.GetString(5);

                    ListViewItem lvi = new ListViewItem(maSV);
                    lvi.SubItems.Add(tenSV);
                    lvi.SubItems.Add(gioiTinh);
                    lvi.SubItems.Add(ngaySinh);
                    lvi.SubItems.Add(queQuan);
                    lvi.SubItems.Add(maLop);

                    lsvDanhSachSV.Items.Add(lvi);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // 📦 Khi chọn 1 dòng trong ListView → đổ dữ liệu lên Form
        private void LsvDanhSachSV_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSachSV.SelectedItems.Count == 0) return;

            ListViewItem item = lsvDanhSachSV.SelectedItems[0];
            txtMaSV.Text = item.SubItems[0].Text;
            txtTenSV.Text = item.SubItems[1].Text;
            cbGioiTinh.Text = item.SubItems[2].Text;
            dtpNgaySinh.Value = DateTime.ParseExact(item.SubItems[3].Text, "dd/MM/yyyy", null);
            txtQueQuan.Text = item.SubItems[4].Text;
            txtMaLop.Text = item.SubItems[5].Text;
        }

        // ✏️ Nút Cập nhật thông tin (không dùng Parameter)
        private void BtnCapNhat_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();

                string maSV = txtMaSV.Text.Trim();
                string tenSV = txtTenSV.Text.Trim();
                string gioiTinh = cbGioiTinh.Text.Trim();
                string ngaySinh = dtpNgaySinh.Value.ToString("yyyy-MM-dd");
                string queQuan = txtQueQuan.Text.Trim();
                string maLop = txtMaLop.Text.Trim();

                if (string.IsNullOrWhiteSpace(maSV))
                {
                    MessageBox.Show("Vui lòng chọn sinh viên cần cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string sql = "UPDATE SinhVien SET " +
                             "TenSV = N'" + tenSV + "', " +
                             "GioiTinh = N'" + gioiTinh + "', " +
                             "NgaySinh = '" + ngaySinh + "', " +
                             "QueQuan = N'" + queQuan + "', " +
                             "MaLop = '" + maLop + "' " +
                             "WHERE MaSV = '" + maSV + "'";

                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                int kq = cmd.ExecuteNonQuery();

                if (kq > 0)
                {
                    MessageBox.Show("✅ Cập nhật thông tin sinh viên thành công!");
                    HienThiDanhSach();
                }
                else
                {
                    MessageBox.Show("❌ Không thể cập nhật sinh viên!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật dữ liệu!\n" + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // 🔄 Nút Thêm sinh viên (dùng lại từ bài trước)
        private void BtnThemSinhVien_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();

                string maSV = txtMaSV.Text.Trim();
                string tenSV = txtTenSV.Text.Trim();
                string gioiTinh = cbGioiTinh.Text;
                string ngaySinh = dtpNgaySinh.Value.ToString("MM/dd/yyyy");
                string queQuan = txtQueQuan.Text.Trim();
                string maLop = txtMaLop.Text.Trim();

                if (string.IsNullOrWhiteSpace(maSV) || string.IsNullOrWhiteSpace(tenSV))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string sql = "INSERT INTO SinhVien VALUES ('" + maSV + "', N'" + tenSV +
                             "', N'" + gioiTinh + "', '" + ngaySinh + "', N'" + queQuan +
                             "', '" + maLop + "')";

                SqlCommand sqlCmd = new SqlCommand(sql, sqlCon);
                int kq = sqlCmd.ExecuteNonQuery();

                if (kq > 0)
                {
                    MessageBox.Show("✅ Thêm sinh viên thành công!");
                    HienThiDanhSach();
                    LamMoiForm();
                }
                else
                {
                    MessageBox.Show("❌ Không thể thêm sinh viên!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm dữ liệu!\n" + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // 🔁 Làm mới Form
        private void LamMoiForm()
        {
            txtMaSV.Clear();
            txtTenSV.Clear();
            txtQueQuan.Clear();
            txtMaLop.Clear();
            cbGioiTinh.SelectedIndex = -1;
            dtpNgaySinh.Value = DateTime.Now;
            txtMaSV.Focus();
        }

        // 🧭 Khi Form load
        private void Form1_Load(object sender, EventArgs e)
        {
            cbGioiTinh.Items.Add("Nam");
            cbGioiTinh.Items.Add("Nữ");
            HienThiDanhSach();
        }
    }
}
