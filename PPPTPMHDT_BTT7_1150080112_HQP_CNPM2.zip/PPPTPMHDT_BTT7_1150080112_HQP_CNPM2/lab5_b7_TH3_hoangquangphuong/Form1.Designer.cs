﻿namespace lab5_b7_TH3_hoangquangphuong
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.groupBoxDanhSach = new System.Windows.Forms.GroupBox();
            this.lsvDanhSachSV = new System.Windows.Forms.ListView();
            this.colMaSV = new System.Windows.Forms.ColumnHeader();
            this.colTenSV = new System.Windows.Forms.ColumnHeader();
            this.colGioiTinh = new System.Windows.Forms.ColumnHeader();
            this.colNgaySinh = new System.Windows.Forms.ColumnHeader();
            this.colQueQuan = new System.Windows.Forms.ColumnHeader();
            this.colMaLop = new System.Windows.Forms.ColumnHeader();
            this.lblChonLop = new System.Windows.Forms.Label();
            this.cbMaLop = new System.Windows.Forms.ComboBox();
            this.groupBoxThongTin = new System.Windows.Forms.GroupBox();
            this.btnSuaThongTin = new System.Windows.Forms.Button();
            this.txtMaSV = new System.Windows.Forms.TextBox();
            this.txtTenSV = new System.Windows.Forms.TextBox();
            this.cbGioiTinh = new System.Windows.Forms.ComboBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtQueQuan = new System.Windows.Forms.TextBox();
            this.txtMaLop = new System.Windows.Forms.TextBox();
            this.lblMaSV = new System.Windows.Forms.Label();
            this.lblTenSV = new System.Windows.Forms.Label();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.lblQueQuan = new System.Windows.Forms.Label();
            this.lblMaLop = new System.Windows.Forms.Label();
            this.groupBoxDanhSach.SuspendLayout();
            this.groupBoxThongTin.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(250, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(287, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Sửa dữ liệu không dùng Parameter";
            // 
            // lblChonLop
            // 
            this.lblChonLop.AutoSize = true;
            this.lblChonLop.Location = new System.Drawing.Point(20, 50);
            this.lblChonLop.Name = "lblChonLop";
            this.lblChonLop.Size = new System.Drawing.Size(88, 20);
            this.lblChonLop.TabIndex = 1;
            this.lblChonLop.Text = "Chọn mã lớp:";
            // 
            // cbMaLop
            // 
            this.cbMaLop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMaLop.FormattingEnabled = true;
            this.cbMaLop.Location = new System.Drawing.Point(115, 47);
            this.cbMaLop.Name = "cbMaLop";
            this.cbMaLop.Size = new System.Drawing.Size(200, 28);
            this.cbMaLop.TabIndex = 2;
            this.cbMaLop.SelectedIndexChanged += new System.EventHandler(this.LsvDanhSachSV_SelectedIndexChanged);
            // 
            // groupBoxDanhSach
            // 
            this.groupBoxDanhSach.Controls.Add(this.lsvDanhSachSV);
            this.groupBoxDanhSach.Location = new System.Drawing.Point(20, 90);
            this.groupBoxDanhSach.Name = "groupBoxDanhSach";
            this.groupBoxDanhSach.Size = new System.Drawing.Size(500, 320);
            this.groupBoxDanhSach.TabIndex = 3;
            this.groupBoxDanhSach.TabStop = false;
            this.groupBoxDanhSach.Text = "Danh sách sinh viên:";
            // 
            // lsvDanhSachSV
            // 
            this.lsvDanhSachSV.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colMaSV,
            this.colTenSV,
            this.colGioiTinh,
            this.colNgaySinh,
            this.colQueQuan,
            this.colMaLop});
            this.lsvDanhSachSV.FullRowSelect = true;
            this.lsvDanhSachSV.GridLines = true;
            this.lsvDanhSachSV.Location = new System.Drawing.Point(10, 25);
            this.lsvDanhSachSV.Name = "lsvDanhSachSV";
            this.lsvDanhSachSV.Size = new System.Drawing.Size(480, 280);
            this.lsvDanhSachSV.TabIndex = 0;
            this.lsvDanhSachSV.UseCompatibleStateImageBehavior = false;
            this.lsvDanhSachSV.View = System.Windows.Forms.View.Details;
            this.lsvDanhSachSV.SelectedIndexChanged += new System.EventHandler(this.LsvDanhSachSV_SelectedIndexChanged);
            // 
            // Các cột ListView
            // 
            this.colMaSV.Text = "Mã SV";
            this.colMaSV.Width = 70;
            this.colTenSV.Text = "Tên SV";
            this.colTenSV.Width = 110;
            this.colGioiTinh.Text = "Giới tính";
            this.colGioiTinh.Width = 70;
            this.colNgaySinh.Text = "Ngày sinh";
            this.colNgaySinh.Width = 100;
            this.colQueQuan.Text = "Quê quán";
            this.colQueQuan.Width = 80;
            this.colMaLop.Text = "Mã lớp";
            this.colMaLop.Width = 70;
            // 
            // groupBoxThongTin
            // 
            this.groupBoxThongTin.Controls.Add(this.btnSuaThongTin);
            this.groupBoxThongTin.Controls.Add(this.txtMaSV);
            this.groupBoxThongTin.Controls.Add(this.txtTenSV);
            this.groupBoxThongTin.Controls.Add(this.cbGioiTinh);
            this.groupBoxThongTin.Controls.Add(this.dtpNgaySinh);
            this.groupBoxThongTin.Controls.Add(this.txtQueQuan);
            this.groupBoxThongTin.Controls.Add(this.txtMaLop);
            this.groupBoxThongTin.Controls.Add(this.lblMaSV);
            this.groupBoxThongTin.Controls.Add(this.lblTenSV);
            this.groupBoxThongTin.Controls.Add(this.lblGioiTinh);
            this.groupBoxThongTin.Controls.Add(this.lblNgaySinh);
            this.groupBoxThongTin.Controls.Add(this.lblQueQuan);
            this.groupBoxThongTin.Controls.Add(this.lblMaLop);
            this.groupBoxThongTin.Location = new System.Drawing.Point(540, 90);
            this.groupBoxThongTin.Name = "groupBoxThongTin";
            this.groupBoxThongTin.Size = new System.Drawing.Size(280, 320);
            this.groupBoxThongTin.TabIndex = 4;
            this.groupBoxThongTin.TabStop = false;
            this.groupBoxThongTin.Text = "Thông tin sinh viên:";
            // 
            // Các Label và TextBox
            // 
            this.lblMaSV.AutoSize = true;
            this.lblMaSV.Location = new System.Drawing.Point(10, 40);
            this.lblMaSV.Name = "lblMaSV";
            this.lblMaSV.Size = new System.Drawing.Size(47, 20);
            this.lblMaSV.Text = "Mã SV:";
            this.txtMaSV.Location = new System.Drawing.Point(100, 37);
            this.txtMaSV.Size = new System.Drawing.Size(160, 27);

            this.lblTenSV.AutoSize = true;
            this.lblTenSV.Location = new System.Drawing.Point(10, 75);
            this.lblTenSV.Text = "Tên SV:";
            this.txtTenSV.Location = new System.Drawing.Point(100, 72);
            this.txtTenSV.Size = new System.Drawing.Size(160, 27);

            this.lblGioiTinh.AutoSize = true;
            this.lblGioiTinh.Location = new System.Drawing.Point(10, 110);
            this.lblGioiTinh.Text = "Giới tính:";
            this.cbGioiTinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGioiTinh.Location = new System.Drawing.Point(100, 107);
            this.cbGioiTinh.Size = new System.Drawing.Size(160, 28);

            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.Location = new System.Drawing.Point(10, 145);
            this.lblNgaySinh.Text = "Ngày sinh:";
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(100, 142);
            this.dtpNgaySinh.Size = new System.Drawing.Size(160, 27);

            this.lblQueQuan.AutoSize = true;
            this.lblQueQuan.Location = new System.Drawing.Point(10, 180);
            this.lblQueQuan.Text = "Quê quán:";
            this.txtQueQuan.Location = new System.Drawing.Point(100, 177);
            this.txtQueQuan.Size = new System.Drawing.Size(160, 27);

            this.lblMaLop.AutoSize = true;
            this.lblMaLop.Location = new System.Drawing.Point(10, 215);
            this.lblMaLop.Text = "Mã lớp:";
            this.txtMaLop.Location = new System.Drawing.Point(100, 212);
            this.txtMaLop.Size = new System.Drawing.Size(160, 27);

            // 
            // btnSuaThongTin
            // 
            this.btnSuaThongTin.Location = new System.Drawing.Point(50, 260);
            this.btnSuaThongTin.Name = "btnSuaThongTin";
            this.btnSuaThongTin.Size = new System.Drawing.Size(180, 35);
            this.btnSuaThongTin.Text = "Sửa thông tin";
            this.btnSuaThongTin.UseVisualStyleBackColor = true;
            this.btnSuaThongTin.Click += new System.EventHandler(this.BtnCapNhat_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(840, 440);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblChonLop);
            this.Controls.Add(this.cbMaLop);
            this.Controls.Add(this.groupBoxDanhSach);
            this.Controls.Add(this.groupBoxThongTin);
            this.Name = "Form1";
            this.Text = "Sửa dữ liệu";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxDanhSach.ResumeLayout(false);
            this.groupBoxThongTin.ResumeLayout(false);
            this.groupBoxThongTin.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox groupBoxDanhSach;
        private System.Windows.Forms.ListView lsvDanhSachSV;
        private System.Windows.Forms.ColumnHeader colMaSV;
        private System.Windows.Forms.ColumnHeader colTenSV;
        private System.Windows.Forms.ColumnHeader colGioiTinh;
        private System.Windows.Forms.ColumnHeader colNgaySinh;
        private System.Windows.Forms.ColumnHeader colQueQuan;
        private System.Windows.Forms.ColumnHeader colMaLop;
        private System.Windows.Forms.Label lblChonLop;
        private System.Windows.Forms.ComboBox cbMaLop;
        private System.Windows.Forms.GroupBox groupBoxThongTin;
        private System.Windows.Forms.Button btnSuaThongTin;
        private System.Windows.Forms.TextBox txtMaSV;
        private System.Windows.Forms.TextBox txtTenSV;
        private System.Windows.Forms.ComboBox cbGioiTinh;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.TextBox txtQueQuan;
        private System.Windows.Forms.TextBox txtMaLop;
        private System.Windows.Forms.Label lblMaSV;
        private System.Windows.Forms.Label lblTenSV;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.Label lblQueQuan;
        private System.Windows.Forms.Label lblMaLop;
    }
}
