﻿namespace lab5_b7_Apdung1_hoangquangphuong
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.groupBoxNhap = new System.Windows.Forms.GroupBox();
            this.lblMaSV = new System.Windows.Forms.Label();
            this.lblTenSV = new System.Windows.Forms.Label();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.lblQueQuan = new System.Windows.Forms.Label();
            this.lblMaLop = new System.Windows.Forms.Label();
            this.txtMaSV = new System.Windows.Forms.TextBox();
            this.txtTenSV = new System.Windows.Forms.TextBox();
            this.cbGioiTinh = new System.Windows.Forms.ComboBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtQueQuan = new System.Windows.Forms.TextBox();
            this.txtMaLop = new System.Windows.Forms.TextBox();
            this.btnThemSV = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.groupBoxDanhSach = new System.Windows.Forms.GroupBox();
            this.lsvDanhSachSV = new System.Windows.Forms.ListView();
            this.colMaSV = new System.Windows.Forms.ColumnHeader();
            this.colTenSV = new System.Windows.Forms.ColumnHeader();
            this.colGioiTinh = new System.Windows.Forms.ColumnHeader();
            this.colNgaySinh = new System.Windows.Forms.ColumnHeader();
            this.colQueQuan = new System.Windows.Forms.ColumnHeader();
            this.colMaLop = new System.Windows.Forms.ColumnHeader();
            this.groupBoxNhap.SuspendLayout();
            this.groupBoxDanhSach.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxNhap
            // 
            this.groupBoxNhap.Controls.Add(this.lblMaSV);
            this.groupBoxNhap.Controls.Add(this.lblTenSV);
            this.groupBoxNhap.Controls.Add(this.lblGioiTinh);
            this.groupBoxNhap.Controls.Add(this.lblNgaySinh);
            this.groupBoxNhap.Controls.Add(this.lblQueQuan);
            this.groupBoxNhap.Controls.Add(this.lblMaLop);
            this.groupBoxNhap.Controls.Add(this.txtMaSV);
            this.groupBoxNhap.Controls.Add(this.txtTenSV);
            this.groupBoxNhap.Controls.Add(this.cbGioiTinh);
            this.groupBoxNhap.Controls.Add(this.dtpNgaySinh);
            this.groupBoxNhap.Controls.Add(this.txtQueQuan);
            this.groupBoxNhap.Controls.Add(this.txtMaLop);
            this.groupBoxNhap.Controls.Add(this.btnThemSV);
            this.groupBoxNhap.Location = new System.Drawing.Point(12, 45);
            this.groupBoxNhap.Name = "groupBoxNhap";
            this.groupBoxNhap.Size = new System.Drawing.Size(300, 350);
            this.groupBoxNhap.TabIndex = 0;
            this.groupBoxNhap.TabStop = false;
            this.groupBoxNhap.Text = "Nhập thông tin:";
            // 
            // Các Label
            // 
            this.lblMaSV.AutoSize = true;
            this.lblMaSV.Location = new System.Drawing.Point(10, 40);
            this.lblMaSV.Name = "lblMaSV";
            this.lblMaSV.Size = new System.Drawing.Size(88, 20);
            this.lblMaSV.Text = "Mã sinh viên:";
            this.lblTenSV.AutoSize = true;
            this.lblTenSV.Location = new System.Drawing.Point(10, 80);
            this.lblTenSV.Text = "Tên sinh viên:";
            this.lblGioiTinh.AutoSize = true;
            this.lblGioiTinh.Location = new System.Drawing.Point(10, 120);
            this.lblGioiTinh.Text = "Giới tính:";
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.Location = new System.Drawing.Point(10, 160);
            this.lblNgaySinh.Text = "Ngày sinh:";
            this.lblQueQuan.AutoSize = true;
            this.lblQueQuan.Location = new System.Drawing.Point(10, 200);
            this.lblQueQuan.Text = "Quê quán:";
            this.lblMaLop.AutoSize = true;
            this.lblMaLop.Location = new System.Drawing.Point(10, 240);
            this.lblMaLop.Text = "Mã lớp:";
            // 
            // TextBox, ComboBox, DateTimePicker
            // 
            this.txtMaSV.Location = new System.Drawing.Point(110, 37);
            this.txtMaSV.Size = new System.Drawing.Size(170, 27);
            this.txtTenSV.Location = new System.Drawing.Point(110, 77);
            this.txtTenSV.Size = new System.Drawing.Size(170, 27);
            this.cbGioiTinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGioiTinh.Items.AddRange(new object[] { "Nam", "Nữ" });
            this.cbGioiTinh.Location = new System.Drawing.Point(110, 117);
            this.cbGioiTinh.Size = new System.Drawing.Size(170, 28);
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(110, 157);
            this.dtpNgaySinh.Size = new System.Drawing.Size(170, 27);
            this.txtQueQuan.Location = new System.Drawing.Point(110, 197);
            this.txtQueQuan.Size = new System.Drawing.Size(170, 27);
            this.txtMaLop.Location = new System.Drawing.Point(110, 237);
            this.txtMaLop.Size = new System.Drawing.Size(170, 27);
            // 
            // btnThemSV
            // 
            this.btnThemSV.Location = new System.Drawing.Point(60, 290);
            this.btnThemSV.Name = "btnThemSV";
            this.btnThemSV.Size = new System.Drawing.Size(180, 35);
            this.btnThemSV.Text = "Thêm sinh viên (Parameter)";
            this.btnThemSV.UseVisualStyleBackColor = true;
            this.btnThemSV.Click += new System.EventHandler(this.BtnThemSinhVien_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(260, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(300, 25);
            this.lblTitle.Text = "Thêm dữ liệu có dùng Parameter";
            // 
            // groupBoxDanhSach
            // 
            this.groupBoxDanhSach.Controls.Add(this.lsvDanhSachSV);
            this.groupBoxDanhSach.Location = new System.Drawing.Point(320, 45);
            this.groupBoxDanhSach.Name = "groupBoxDanhSach";
            this.groupBoxDanhSach.Size = new System.Drawing.Size(600, 350);
            this.groupBoxDanhSach.TabIndex = 2;
            this.groupBoxDanhSach.TabStop = false;
            this.groupBoxDanhSach.Text = "Danh sách sinh viên:";
            // 
            // lsvDanhSachSV
            // 
            this.lsvDanhSachSV.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colMaSV,
            this.colTenSV,
            this.colGioiTinh,
            this.colNgaySinh,
            this.colQueQuan,
            this.colMaLop});
            this.lsvDanhSachSV.FullRowSelect = true;
            this.lsvDanhSachSV.GridLines = true;
            this.lsvDanhSachSV.Location = new System.Drawing.Point(10, 30);
            this.lsvDanhSachSV.Name = "lsvDanhSachSV";
            this.lsvDanhSachSV.Size = new System.Drawing.Size(580, 300);
            this.lsvDanhSachSV.TabIndex = 0;
            this.lsvDanhSachSV.UseCompatibleStateImageBehavior = false;
            this.lsvDanhSachSV.View = System.Windows.Forms.View.Details;
            // 
            // Columns
            // 
            this.colMaSV.Text = "Mã SV";
            this.colMaSV.Width = 80;
            this.colTenSV.Text = "Tên SV";
            this.colTenSV.Width = 120;
            this.colGioiTinh.Text = "Giới tính";
            this.colGioiTinh.Width = 70;
            this.colNgaySinh.Text = "Ngày sinh";
            this.colNgaySinh.Width = 100;
            this.colQueQuan.Text = "Quê quán";
            this.colQueQuan.Width = 120;
            this.colMaLop.Text = "Mã lớp";
            this.colMaLop.Width = 80;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 420);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.groupBoxNhap);
            this.Controls.Add(this.groupBoxDanhSach);
            this.Name = "Form1";
            this.Text = "Thêm dữ liệu có dùng Parameter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxNhap.ResumeLayout(false);
            this.groupBoxNhap.PerformLayout();
            this.groupBoxDanhSach.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxNhap;
        private System.Windows.Forms.Label lblMaSV;
        private System.Windows.Forms.Label lblTenSV;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.Label lblQueQuan;
        private System.Windows.Forms.Label lblMaLop;
        private System.Windows.Forms.TextBox txtMaSV;
        private System.Windows.Forms.TextBox txtTenSV;
        private System.Windows.Forms.ComboBox cbGioiTinh;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.TextBox txtQueQuan;
        private System.Windows.Forms.TextBox txtMaLop;
        private System.Windows.Forms.Button btnThemSV;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox groupBoxDanhSach;
        private System.Windows.Forms.ListView lsvDanhSachSV;
        private System.Windows.Forms.ColumnHeader colMaSV;
        private System.Windows.Forms.ColumnHeader colTenSV;
        private System.Windows.Forms.ColumnHeader colGioiTinh;
        private System.Windows.Forms.ColumnHeader colNgaySinh;
        private System.Windows.Forms.ColumnHeader colQueQuan;
        private System.Windows.Forms.ColumnHeader colMaLop;
    }
}
