﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab5_b7_Apdung1_hoangquangphuong
{
    public partial class Form1 : Form
    {
        // 🔗 Chuỗi kết nối tới file database .mdf
        private readonly string strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;
                                           AttachDbFilename=|DataDirectory|\1150080112_hoangquangphuong_lab5.mdf;
                                           Integrated Security=True";

        private SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        // 📂 Hàm mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // 📁 Hàm đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // 📋 Hiển thị danh sách sinh viên
        private void HienThiDanhSach()
        {
            try
            {
                MoKetNoi();
                SqlCommand cmd = new SqlCommand("SELECT * FROM SinhVien", sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();
                lsvDanhSachSV.Items.Clear();

                while (reader.Read())
                {
                    string maSV = reader.GetString(0);
                    string tenSV = reader.GetString(1);
                    string gioiTinh = reader.GetString(2);
                    string ngaySinh = reader.GetDateTime(3).ToString("dd/MM/yyyy");
                    string queQuan = reader.GetString(4);
                    string maLop = reader.GetString(5);

                    ListViewItem item = new ListViewItem(maSV);
                    item.SubItems.Add(tenSV);
                    item.SubItems.Add(gioiTinh);
                    item.SubItems.Add(ngaySinh);
                    item.SubItems.Add(queQuan);
                    item.SubItems.Add(maLop);

                    lsvDanhSachSV.Items.Add(item);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // ➕ Nút Thêm sinh viên (có dùng Parameter)
        private void BtnThemSinhVien_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();

                string maSV = txtMaSV.Text.Trim();
                string tenSV = txtTenSV.Text.Trim();
                string gioiTinh = cbGioiTinh.Text;
                DateTime ngaySinh = dtpNgaySinh.Value;
                string queQuan = txtQueQuan.Text.Trim();
                string maLop = txtMaLop.Text.Trim();

                if (string.IsNullOrWhiteSpace(maSV) || string.IsNullOrWhiteSpace(tenSV))
                {
                    MessageBox.Show("⚠️ Vui lòng nhập đầy đủ thông tin!");
                    return;
                }

                // ✅ Dùng Parameter thay vì nối chuỗi SQL
                string sql = "INSERT INTO SinhVien (MaSV, TenSV, GioiTinh, NgaySinh, QueQuan, MaLop) " +
                             "VALUES (@MaSV, @TenSV, @GioiTinh, @NgaySinh, @QueQuan, @MaLop)";

                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSV", maSV);
                cmd.Parameters.AddWithValue("@TenSV", tenSV);
                cmd.Parameters.AddWithValue("@GioiTinh", gioiTinh);
                cmd.Parameters.AddWithValue("@NgaySinh", ngaySinh);
                cmd.Parameters.AddWithValue("@QueQuan", queQuan);
                cmd.Parameters.AddWithValue("@MaLop", maLop);

                int kq = cmd.ExecuteNonQuery();

                if (kq > 0)
                {
                    MessageBox.Show("✅ Thêm sinh viên thành công (dùng Parameter)!");
                    HienThiDanhSach();
                    LamMoiForm();
                }
                else
                {
                    MessageBox.Show("❌ Không thể thêm sinh viên!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm dữ liệu!\n" + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // 🔄 Làm mới form
        private void LamMoiForm()
        {
            txtMaSV.Clear();
            txtTenSV.Clear();
            txtQueQuan.Clear();
            txtMaLop.Clear();
            cbGioiTinh.SelectedIndex = -1;
            dtpNgaySinh.Value = DateTime.Now;
            txtMaSV.Focus();
        }

        // 📅 Khi form load
        private void Form1_Load(object sender, EventArgs e)
        {
            cbGioiTinh.Items.Add("Nam");
            cbGioiTinh.Items.Add("Nữ");
            HienThiDanhSach();
        }
    }
}
